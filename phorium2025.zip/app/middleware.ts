import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const betaCookie = req.cookies.get("phorium-beta")?.value;

  // Disse skal alltid være tilgjengelige uten kode
  const publicPaths = ["/beta"];

  // Hopp over Next.js sine egne filer og statiske greier
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/images") ||
    pathname.startsWith("/assets")
  ) {
    return NextResponse.next();
  }

  const isPublic = publicPaths.some((path) =>
    pathname === path || pathname.startsWith(path + "/")
  );

  // 1) Ingen cookie → ALT (inkl. "/") går til /beta
  if (!betaCookie) {
    if (!isPublic) {
      const url = req.nextUrl.clone();
      url.pathname = "/beta";
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  // 2) Har cookie → hvis de står på /beta, send dem til forsiden
  if (betaCookie && pathname === "/beta") {
    const url = req.nextUrl.clone();
    url.pathname = "/";
    return NextResponse.redirect(url);
  }

  // 3) Har cookie → får gå hvor som helst
  return NextResponse.next();
}

export const config = {
  // Kjør middleware på alle "vanlige" paths
  matcher: ["/((?!_next|static|favicon.ico).*)"],
};

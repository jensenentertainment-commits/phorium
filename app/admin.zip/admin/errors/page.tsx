import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import AdminNav from "../AdminNav";

type ErrorRow = {
  id: string;
  created_at: string;
  user_id: string | null;
  context: string | null;
  path: string | null;
  severity: string;
  message: string;
  resolved: boolean;
};

export default async function AdminErrorsPage({
  searchParams,
}: {
  searchParams?: { severity?: string; resolved?: string };
}) {
  const cookieStore = await cookies();
  const isAdmin = cookieStore.get("phorium_admin")?.value === "1";

  if (!isAdmin) {
    redirect("/admin/login");
  }

  const severity = searchParams?.severity ?? "all";
  const showResolved = searchParams?.resolved === "1";

  let query = supabaseAdmin
    .from("error_log")
    .select(
      "id, created_at, user_id, context, path, severity, message, resolved",
    )
    .order("created_at", { ascending: false })
    .limit(200);

  if (severity !== "all") {
    query = query.eq("severity", severity);
  }

  if (!showResolved) {
    query = query.eq("resolved", false);
  }

  const { data, error } = await query;
  const errors = (data ?? []) as ErrorRow[];

  return (
    <main className="min-h-screen bg-phorium-dark pt-24 pb-16 text-phorium-light">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4">
        <AdminNav />

        <header className="flex flex-col gap-2">
          <p className="text-[11px] uppercase tracking-[0.18em] text-phorium-light/50">
            Admin
          </p>
          <h1 className="text-2xl font-semibold">Error logg</h1>
          <p className="text-[13px] text-phorium-light/70">
            Oversikt over registrerte feil i Phorium. Fint å sjekke hvis noe
            oppfører seg rart.
          </p>
        </header>

        {/* Filtre */}
        <section className="flex flex-wrap items-center gap-3 rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
          <form className="flex flex-wrap items-center gap-3 text-[12px]">
            <label className="flex items-center gap-2">
              <span className="text-phorium-light/70">Severity</span>
              <select
                name="severity"
                defaultValue={severity}
                className="rounded-full border border-phorium-off/40 bg-phorium-dark px-3 py-1 text-[12px]"
              >
                <option value="all">Alle</option>
                <option value="error">Error</option>
                <option value="warning">Warning</option>
                <option value="info">Info</option>
              </select>
            </label>

            <label className="flex items-center gap-2 text-phorium-light/70">
              <input
                type="checkbox"
                name="resolved"
                value="1"
                defaultChecked={showResolved}
                className="h-3 w-3 rounded border border-phorium-off/60 bg-phorium-dark"
              />
              Vis løste
            </label>

            <button
              type="submit"
              className="rounded-full border border-phorium-off/50 bg-phorium-dark px-4 py-1 text-[11px] font-medium tracking-wide uppercase text-phorium-light/80"
            >
              Oppdater
            </button>
          </form>

          {error && (
            <p className="text-[11px] text-red-400">
              Kunne ikke hente errors: {error.message}
            </p>
          )}
        </section>

        {/* Liste */}
        <section className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
          <h2 className="text-sm font-semibold text-phorium-light">
            Siste errors
          </h2>
          <p className="mt-1 text-[12px] text-phorium-light/65">
            Viser opptil 200 rader, nyere først.
          </p>

          {errors.length === 0 ? (
            <p className="mt-4 text-[12px] text-phorium-light/60">
              Ingen errors funnet med disse filtrene. Enten er alt perfekt – eller
              vi logger ikke riktig ennå 😅
            </p>
          ) : (
            <div className="mt-4 space-y-2">
              {errors.map((err) => {
                const when = new Date(err.created_at).toLocaleString("nb-NO", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                });

                return (
                  <div
                    key={err.id}
                    className="rounded-xl border border-phorium-off/30 bg-phorium-dark/90 p-3 text-[12px]"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide
                            ${
                              err.severity === "error"
                                ? "bg-red-500/15 text-red-300"
                                : err.severity === "warning"
                                ? "bg-amber-500/15 text-amber-300"
                                : "bg-phorium-accent/15 text-phorium-accent"
                            }`}
                        >
                          {err.severity || "ERROR"}
                        </span>
                        {err.context && (
                          <span className="rounded-full bg-phorium-off/20 px-2 py-0.5 text-[10px] text-phorium-light/80">
                            {err.context}
                          </span>
                        )}
                        {err.path && (
                          <span className="rounded-full bg-phorium-off/10 px-2 py-0.5 text-[10px] text-phorium-light/70">
                            {err.path}
                          </span>
                        )}
                      </div>

                      <span className="text-[11px] text-phorium-light/55">
                        {when}
                      </span>
                    </div>

                    <p className="mt-2 text-[12px] text-phorium-light/90">
                      {err.message}
                    </p>

                    <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-phorium-light/60">
                      <span>
                        {err.user_id
                          ? `User: ${err.user_id}`
                          : "Ingen user_id"}
                      </span>
                      {err.resolved && (
                        <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] text-emerald-300">
                          Markert som løst
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

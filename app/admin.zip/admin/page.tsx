import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import AdminNav from "./AdminNav";


type ActivityRow = {
  id: string;
  user_id: string | null;
  email_snapshot: string | null;
  event_type: string;
  meta: any;
  created_at: string;
};

export default async function AdminDashboardPage() {
  // Next 16: cookies() er async
  const cookieStore = await cookies();
  const isAdmin = cookieStore.get("phorium_admin")?.value === "1";

  if (!isAdmin) {
    redirect("/admin/login");
  }

  const now = new Date();
  const since24h = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
  const since7d = new Date(
    now.getTime() - 7 * 24 * 60 * 60 * 1000,
  ).toISOString();

  // Hent flere ting i parallell
  const [
    totalEventsRes,
    text24hRes,
    image24hRes,
    campaign24hRes,
    creditsChangedRes,
    activeUsers7dRes,
    last10Res,
    last200Res,
    errors24hRes, 
  ] = await Promise.all([
    // Totalt antall hendelser
    supabaseAdmin
      .from("activity_log")
      .select("*", { count: "exact", head: true }),

    // Tekstgenereringer siste 24 timer
    supabaseAdmin
      .from("activity_log")
      .select("*", { count: "exact", head: true })
      .eq("event_type", "TEXT_GENERATED")
      .gte("created_at", since24h),

    // Bildegenereringer (enkeltbilder) siste 24 timer
    supabaseAdmin
      .from("activity_log")
      .select("*", { count: "exact", head: true })
      .eq("event_type", "IMAGE_GENERATED")
      .gte("created_at", since24h),

    // Kampanjepakker siste 24 timer
    supabaseAdmin
      .from("activity_log")
      .select("*", { count: "exact", head: true })
      .eq("event_type", "CAMPAIGN_GENERATED")
      .gte("created_at", since24h),

    // Kreditt-endringer totalt
    supabaseAdmin
      .from("activity_log")
      .select("*", { count: "exact", head: true })
      .eq("event_type", "CREDITS_CHANGED"),

    // Aktive brukere siste 7 dager (distinct user_id)
    supabaseAdmin
      .from("activity_log")
      .select("user_id", { count: "exact", head: true })
      .not("user_id", "is", null)
      .gte("created_at", since7d),

    // Siste 10 hendelser
    supabaseAdmin
      .from("activity_log")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(10),

    // Siste 200 hendelser til enkel "per dag"-graf
    supabaseAdmin
      .from("activity_log")
      .select("id, created_at, event_type")
      .order("created_at", { ascending: true })
      .limit(200),
  ]);

  const totalEvents = totalEventsRes.count ?? 0;
  const text24h = text24hRes.count ?? 0;
  const image24h = image24hRes.count ?? 0;
  const campaign24h = campaign24hRes.count ?? 0;
  const creditsChangedTotal = creditsChangedRes.count ?? 0;
  const activeUsers7d = activeUsers7dRes.count ?? 0;
  const last10 = (last10Res.data ?? []) as ActivityRow[];
  const last200 = (last200Res.data ?? []) as ActivityRow[];
  const errors24h = errors24hRes.count ?? 0;

  // Bygg en enkel "events per dag"-graf fra siste 200 events
  const eventsPerDayMap = new Map<string, number>();
  for (const row of last200) {
    const d = new Date(row.created_at);
    const key = d.toISOString().slice(0, 10); // YYYY-MM-DD
    eventsPerDayMap.set(key, (eventsPerDayMap.get(key) ?? 0) + 1);
  }

  const eventsPerDay = Array.from(eventsPerDayMap.entries()).sort(
    ([a], [b]) => (a < b ? -1 : 1),
  );

  const maxEventsPerDay =
    eventsPerDay.reduce((max, [, count]) => Math.max(max, count), 0) || 1;

  return (
    <main className="min-h-screen bg-phorium-dark pt-24 pb-16 text-phorium-light">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4">
        <AdminNav />
        {/* Header */}
        <header className="flex flex-col gap-2">
          <p className="text-[11px] uppercase tracking-[0.18em] text-phorium-light/50">
            Admin
          </p>
          <h1 className="text-2xl font-semibold">Phorium Dashboard</h1>
          <p className="text-[13px] text-phorium-light/70">
            Høydepunkt fra aktivitetlogg og kredittbruk i betaversjonen.
          </p>
        </header>

        {/* KPI-rad */}
        <section className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
          <KpiCard
            label="Totalt registrerte hendelser"
            value={totalEvents}
            helper="Alle events i activity_log"
          />
          <KpiCard
            label="Aktive brukere (7 dager)"
            value={activeUsers7d}
            helper="Distinct user_id i activity_log siste 7 dager"
          />
          <KpiCard
            label="Tekstgenereringer (24 t)"
            value={text24h}
            helper="TEXT_GENERATED siste 24 timer"
          />
          <KpiCard
            label="Bilde/kampanje (24 t)"
            value={image24h + campaign24h}
            helper="IMAGE_GENERATED + CAMPAIGN_GENERATED siste 24 timer"
          />
          <KpiCard
            label="Kreditt-endringer (totalt)"
            value={creditsChangedTotal}
            helper="Antall CREDITS_CHANGED-events"
          />
        </section>

        {/* Midtrad: graf + siste hendelser */}
        <section className="grid gap-6 lg:grid-cols-[2fr,3fr]">
          {/* Enkel "per dag"-graf */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <h2 className="text-sm font-semibold text-phorium-light">
              Hendelser per dag (siste periode)
            </h2>
            <p className="mt-1 text-[12px] text-phorium-light/65">
              Basert på de siste {last200.length} eventene i activity_log.
            </p>

            {eventsPerDay.length === 0 ? (
              <p className="mt-4 text-[12px] text-phorium-light/60">
                Ingen data ennå. Når brukere begynner å generere, dukker
                aktivitet opp her.
              </p>
            ) : (
              <div className="mt-4 flex h-40 items-end gap-1 rounded-xl bg-phorium-dark/70 p-3">
                {eventsPerDay.map(([day, count]) => {
                  const height = (count / maxEventsPerDay) * 100;
                  const dateLabel = new Date(day).toLocaleDateString("nb-NO", {
                    day: "2-digit",
                    month: "2-digit",
                  });

                  return (
                    <div
                      key={day}
                      className="flex flex-1 flex-col items-center justify-end gap-1"
                    >
                      <div
                        className="w-full rounded-full bg-phorium-accent/70"
                        style={{ height: `${height || 8}%` }}
                        title={`${dateLabel}: ${count} hendelser`}
                      />
                      <span className="mt-1 text-[9px] text-phorium-light/55">
                        {dateLabel}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

                  <section className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
          <KpiCard
            label="Totalt registrerte hendelser"
            value={totalEvents}
            helper="Alle events i activity_log"
          />
          <KpiCard
            label="Aktive brukere (7 dager)"
            value={activeUsers7d}
            helper="Distinct user_id i activity_log siste 7 dager"
          />
          <KpiCard
            label="Tekstgenereringer (24 t)"
            value={text24h}
            helper="TEXT_GENERATED siste 24 timer"
          />
          <KpiCard
            label="Bilde/kampanje (24 t)"
            value={image24h + campaign24h}
            helper="IMAGE_GENERATED + CAMPAIGN_GENERATED siste 24 timer"
          />
          <KpiCard
            label="Kreditt-endringer (totalt)"
            value={creditsChangedTotal}
            helper="Antall CREDITS_CHANGED-events"
          />
          {/* 👇 Ny KPI */}
          <KpiCard
            label="Errors (24 t)"
            value={errors24h}
            helper="Antall rader i error_log siste 24 timer"
          />
        </section>


          {/* Siste hendelser */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <h2 className="text-sm font-semibold text-phorium-light">
              Siste aktivitet
            </h2>
            <p className="mt-1 text-[12px] text-phorium-light/65">
              De 10 siste registrerte hendelsene fra brukere og system.
            </p>

            <div className="mt-3 space-y-2">
              {last10.map((row) => {
                const when = new Date(row.created_at).toLocaleString("nb-NO", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                });

                return (
                  <div
                    key={row.id}
                    className="rounded-xl border border-phorium-off/25 bg-phorium-dark/80 p-3 text-[12px]"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="rounded-full bg-phorium-accent/15 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-phorium-accent">
                        {row.event_type}
                      </span>
                      <span className="text-[11px] text-phorium-light/55">
                        {when}
                      </span>
                    </div>
                    <div className="mt-1 text-phorium-light/80">
                      {row.email_snapshot ? (
                        <span className="text-[11px] text-phorium-light/75">
                          {row.email_snapshot}
                        </span>
                      ) : (
                        <span className="text-[11px] text-phorium-light/45">
                          (ingen e-post)
                        </span>
                      )}
                    </div>
                    {row.meta && Object.keys(row.meta).length > 0 && (
                      <pre className="mt-2 max-h-24 overflow-auto whitespace-pre-wrap text-[10px] leading-tight text-phorium-light/70">
                        {JSON.stringify(row.meta, null, 2)}
                      </pre>
                    )}
                  </div>
                );
              })}

              {last10.length === 0 && (
                <p className="mt-4 text-[12px] text-phorium-light/60">
                  Ingen hendelser ennå. Når du og beta-brukere begynner å
                  generere tekst og bilder, dukker ting opp her.
                </p>
              )}
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

// Enkel KPI-komponent
function KpiCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: number;
  helper?: string;
}) {
  return (
    <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
      <p className="text-[11px] text-phorium-light/60">{label}</p>
      <p className="mt-1 text-xl font-semibold text-phorium-light">
        {value}
      </p>
      {helper && (
        <p className="mt-1 text-[11px] text-phorium-light/45">{helper}</p>
      )}
    </div>
  );
}

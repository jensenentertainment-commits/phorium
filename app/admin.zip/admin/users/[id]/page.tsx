import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import AdminNav from "../../AdminNav";

type ActivityRow = {
  id: string;
  created_at: string;
  event_type: string;
  meta: any;
};

type ErrorRow = {
  id: string;
  created_at: string;
  message: string;
  severity: string;
};

export default async function AdminUserDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const cookieStore = await cookies();
  const isAdmin = cookieStore.get("phorium_admin")?.value === "1";

  if (!isAdmin) {
    redirect("/admin/login");
  }

  const userId = params.id;

  // 1) Auth-bruker
  const { data: authRes, error: authError } =
    await supabaseAdmin.auth.admin.getUserById(userId);

  if (authError || !authRes?.user) {
    redirect("/admin/users");
  }

  const user = authRes.user;

  // 2) Profil / credits / plan (tilpass tabell/felter til ditt schema)
  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("brand_name, plan, credits")
    .eq("id", userId)
    .maybeSingle();

  // 3) Aggregert aktivitet
  const { data: activityAgg } = await supabaseAdmin
    .from("activity_log")
    .select("count(*)::int as events, max(created_at) as last_activity")
    .eq("user_id", userId)
    .maybeSingle();

  // 4) Siste aktivitet og errors
  const [{ data: activityRows }, { data: errorRows }] = await Promise.all([
    supabaseAdmin
      .from("activity_log")
      .select("id, created_at, event_type, meta")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(20),
    supabaseAdmin
      .from("error_log")
      .select("id, created_at, message, severity")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(10),
  ]);

  const activity = (activityRows ?? []) as ActivityRow[];
  const errors = (errorRows ?? []) as ErrorRow[];

  const createdAt = new Date(user.created_at).toLocaleString("nb-NO", {
    dateStyle: "short",
    timeStyle: "short",
  });

  const lastSignIn = user.last_sign_in_at
    ? new Date(user.last_sign_in_at).toLocaleString("nb-NO", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : null;

  const lastActivity =
    activityAgg?.last_activity &&
    new Date(activityAgg.last_activity as string).toLocaleString("nb-NO", {
      dateStyle: "short",
      timeStyle: "short",
    });

  return (
    <main className="min-h-screen bg-phorium-dark pt-24 pb-16 text-phorium-light">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4">
        <AdminNav />

        {/* Header */}
        <header className="flex flex-col gap-2">
          <p className="text-[11px] uppercase tracking-[0.18em] text-phorium-light/50">
            Admin · Bruker
          </p>
          <h1 className="text-2xl font-semibold">
            {user.email ?? "Uten e-post"}
          </h1>
          <p className="text-[12px] text-phorium-light/70">
            ID:{" "}
            <span className="font-mono text-[11px] text-phorium-light/80">
              {user.id}
            </span>
          </p>
        </header>

        {/* Info-kort */}
        <section className="grid gap-4 md:grid-cols-3">
          {/* Konto */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <p className="text-[11px] text-phorium-light/60">Konto</p>
            <dl className="mt-2 space-y-1 text-[12px]">
              <div>
                <dt className="text-phorium-light/50">Opprettet</dt>
                <dd className="text-phorium-light/90">{createdAt}</dd>
              </div>
              <div>
                <dt className="text-phorium-light/50">Sist innlogget</dt>
                <dd className="text-phorium-light/90">
                  {lastSignIn ?? "Ingen data"}
                </dd>
              </div>
            </dl>
          </div>

          {/* Plan & credits */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <p className="text-[11px] text-phorium-light/60">
              Plan & kreditter
            </p>
            <dl className="mt-2 space-y-1 text-[12px]">
              <div>
                <dt className="text-phorium-light/50">Plan</dt>
                <dd className="text-phorium-light/90">
                  {profile?.plan ?? "Ingen (beta / free)"}
                </dd>
              </div>
              <div>
                <dt className="text-phorium-light/50">Kreditter</dt>
                <dd className="text-phorium-light/90">
                  {profile?.credits ?? 0}
                </dd>
              </div>
              {profile?.brand_name && (
                <div>
                  <dt className="text-phorium-light/50">Brand</dt>
                  <dd className="text-phorium-light/90">
                    {profile.brand_name}
                  </dd>
                </div>
              )}
            </dl>
          </div>

          {/* Aktivitet */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <p className="text-[11px] text-phorium-light/60">Aktivitet</p>
            <dl className="mt-2 space-y-1 text-[12px]">
              <div>
                <dt className="text-phorium-light/50">Totalt events</dt>
                <dd className="text-phorium-light/90">
                  {(activityAgg?.events as number) ?? 0}
                </dd>
              </div>
              <div>
                <dt className="text-phorium-light/50">Sist aktiv</dt>
                <dd className="text-phorium-light/90">
                  {lastActivity ?? "Ingen aktivitet"}
                </dd>
              </div>
            </dl>
          </div>
        </section>

        {/* Aktivitet + errors */}
        <section className="grid gap-6 lg:grid-cols-2">
          {/* Siste aktivitet */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <h2 className="text-sm font-semibold text-phorium-light">
              Siste aktivitet
            </h2>
            <p className="mt-1 text-[12px] text-phorium-light/65">
              De 20 siste eventene fra denne brukeren.
            </p>

            {activity.length === 0 ? (
              <p className="mt-4 text-[12px] text-phorium-light/60">
                Ingen registrert aktivitet ennå.
              </p>
            ) : (
              <div className="mt-3 space-y-2">
                {activity.map((row) => {
                  const when = new Date(row.created_at).toLocaleString("nb-NO", {
                    day: "2-digit",
                    month: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                  });

                  return (
                    <div
                      key={row.id}
                      className="rounded-xl border border-phorium-off/25 bg-phorium-dark/80 p-3 text-[12px]"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="rounded-full bg-phorium-accent/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-phorium-accent">
                          {row.event_type}
                        </span>
                        <span className="text-[11px] text-phorium-light/55">
                          {when}
                        </span>
                      </div>
                      {row.meta && Object.keys(row.meta).length > 0 && (
                        <pre className="mt-2 max-h-24 overflow-auto whitespace-pre-wrap text-[10px] leading-tight text-phorium-light/70">
                          {JSON.stringify(row.meta, null, 2)}
                        </pre>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Siste errors */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            <h2 className="text-sm font-semibold text-phorium-light">
              Siste errors
            </h2>
            <p className="mt-1 text-[12px] text-phorium-light/65">
              Feil knyttet til denne brukeren.
            </p>

            {errors.length === 0 ? (
              <p className="mt-4 text-[12px] text-phorium-light/60">
                Ingen registrerte errors for denne brukeren.
              </p>
            ) : (
              <div className="mt-3 space-y-2">
                {errors.map((err) => {
                  const when = new Date(err.created_at).toLocaleString(
                    "nb-NO",
                    {
                      day: "2-digit",
                      month: "2-digit",
                      hour: "2-digit",
                      minute: "2-digit",
                    },
                  );

                  return (
                    <div
                      key={err.id}
                      className="rounded-xl border border-red-500/30 bg-red-500/5 p-3 text-[12px]"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-red-200">
                          {err.severity || "ERROR"}
                        </span>
                        <span className="text-[11px] text-phorium-light/70">
                          {when}
                        </span>
                      </div>
                      <p className="mt-2 text-[12px] text-phorium-light/95">
                        {err.message}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}

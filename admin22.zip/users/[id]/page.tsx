import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import AdminNav from "../../AdminNav";
import UserAdminClient from "./UserAdminClient";

type AdminActionRow = {
  id: string;
  created_at: string;
  action: string;
  delta_credits: number | null;
  old_plan: string | null;
  new_plan: string | null;
  admin_label: string | null;
};

type ErrorRow = {
  id: string;
  created_at: string;
  message: string;
  severity: string;
};

export default async function AdminUserDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const cookieStore = await cookies();
  const isAdmin = cookieStore.get("phorium_admin")?.value === "1";

  if (!isAdmin) {
    redirect("/admin/login");
  }

  const userId = params.id;

  // 1) Auth-bruker
  const { data: authRes, error: authError } =
    await supabaseAdmin.auth.admin.getUserById(userId);

  if (authError || !authRes?.user) {
    redirect("/admin/users");
  }

  const user = authRes.user;

  // 2) Profil / plan / credits (fra profiles-tabell)
  const { data: profile } = await supabaseAdmin
    .from("profiles")
    .select("brand_name, plan, credits")
    .eq("id", userId)
    .maybeSingle();

  // 3) Kreditter (fra credits-tabellen)
  const { data: creditRow } = await supabaseAdmin
    .from("credits")
    .select("balance, quota")
    .eq("user_id", userId)
    .maybeSingle();

  const creditsBalance = creditRow?.balance ?? profile?.credits ?? 0;
  const creditsQuota = creditRow?.quota ?? null;

 // 4) Aktivitet + errors + admin actions
const [activityRes, errorRes, adminActionsRes] = await Promise.all([
  supabaseAdmin
    .from("activity_log")
    .select("id, created_at, event_type, meta", { count: "exact" })
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(20),

  supabaseAdmin
    .from("error_log")
    .select("id, created_at, message, severity")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })
    .limit(10),

  supabaseAdmin
    .from("admin_actions")
    .select(
      "id, created_at, action, delta_credits, old_plan, new_plan, admin_label"
    )
    .eq("target_user_id", userId)
    .order("created_at", { ascending: false })
    .limit(20),
]);

// 👉 Her skal linja din stå:
const activity = (activityRes.data ?? []) as ActivityRow[];
const errors = (errorRes.data ?? []) as ErrorRow[];
const adminActions = (adminActionsRes.data ?? []) as AdminActionRow[];

const totalEvents = activityRes.count ?? 0;

const lastActivity =
  activity.length > 0 ? activity[0].created_at : null;

  const createdAt = user.created_at
    ? new Date(user.created_at).toLocaleString("nb-NO", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : "—";

  const lastSignIn = user.last_sign_in_at
    ? new Date(user.last_sign_in_at).toLocaleString("nb-NO", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : null;

  const lastActivityFormatted = lastActivity
    ? new Date(lastActivity).toLocaleString("nb-NO", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : null;

  const initialPlan = profile?.plan ?? null;

    return (
    <main className="min-h-screen bg-phorium-dark pt-0 pb-16 text-phorium-light">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4">
        <AdminNav />

        {/* Header */}
        <header className="flex flex-col gap-2">
          <p className="text-[11px] uppercase tracking-[0.18em] text-phorium-light/50">
            Admin · Bruker
          </p>
          <h1 className="text-2xl font-semibold">
            {user.email ?? "Uten e-post"}
          </h1>
          <p className="text-[12px] text-phorium-light/70">
            ID:{" "}
            <span className="font-mono text-[11px] text-phorium-light/80">
              {user.id}
            </span>
          </p>
        </header>

        {/* Info-kort */}
        <section className="grid gap-4 md:grid-cols-3">
          {/* Konto-kort ... */}
          {/* Plan & credits + <UserAdminClient ... /> */}
          {/* Aktivitet-kort ... */}
        </section>

        {/* Aktivitet + errors */}
        <section className="grid gap-6 lg:grid-cols-2">
          {/* Siste aktivitet */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            {/* ... innholdet for activity-lista ... */}
          </div>

          {/* Siste errors */}
          <div className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
            {/* ... innholdet for errors-lista ... */}
          </div>
        </section>

        {/* 👇 HER legger du inn admin-actions seksjonen */}
        <section className="rounded-2xl border border-phorium-off/30 bg-phorium-dark/80 p-4 shadow-[0_12px_40px_rgba(0,0,0,0.55)]">
          <h2 className="text-sm font-semibold text-phorium-light">
            Admin-historikk
          </h2>
          <p className="mt-1 text-[12px] text-phorium-light/65">
            Endringer gjort via admin-panelet (plan og kreditter).
          </p>

          {adminActions.length === 0 ? (
            <p className="mt-4 text-[12px] text-phorium-light/60">
              Ingen registrerte admin-actions for denne brukeren ennå.
            </p>
          ) : (
            <div className="mt-3 space-y-2 text-[12px]">
              {adminActions.map((a) => {
                const when = new Date(
                  a.created_at,
                ).toLocaleString("nb-NO", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                });

                let description = a.action;
                if (a.action === "CREDITS_ADJUST" && a.delta_credits) {
                  description = `Kreditter justert med ${
                    a.delta_credits > 0 ? "+" : ""
                  }${a.delta_credits}`;
                }
                if (a.action === "PLAN_CHANGE") {
                  description = `Plan endret fra ${
                    a.old_plan ?? "Ingen"
                  } til ${a.new_plan ?? "Ingen"}`;
                }

                return (
                  <div
                    key={a.id}
                    className="rounded-xl border border-phorium-off/25 bg-phorium-dark/80 p-3"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-phorium-light/90">
                        {description}
                      </span>
                      <span className="text-[11px] text-phorium-light/55">
                        {when}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between gap-2 text-[11px] text-phorium-light/60">
                      <span>
                        Utført av{" "}
                        {a.admin_label ? a.admin_label : "admin"}
                      </span>
                      <span className="text-[10px] text-phorium-light/50">
                        ID: {a.id}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

// app/studio/layout.tsx
import type { ReactNode } from "react";
import TopStudioNav from "@/app/components/TopStudioNav";

export default function StudioLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[70vh] bg-[#11140F] text-[#ECE8DA]">
      {/* Studio-nav for alle /studio-sider */}
      <TopStudioNav />

      {/* Selve studio-innholdet */}
      <main className="w-full max-w-6xl mx-auto px-4 py-10">
        {children}
      </main>
    </div>
  );
}
